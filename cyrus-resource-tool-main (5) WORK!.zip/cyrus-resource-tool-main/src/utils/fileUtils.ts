// This file now just re-exports everything from the file subdirectory
// We keep this file for backward compatibility with existing imports
export * from './file';
