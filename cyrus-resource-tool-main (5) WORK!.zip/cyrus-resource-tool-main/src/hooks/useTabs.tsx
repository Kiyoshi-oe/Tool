
import { useState } from "react";
import { ResourceItem } from "../types/fileTypes";

interface TabItem {
  id: string;
  item: ResourceItem;
}

export const useTabs = (
  selectedItem: ResourceItem | null, 
  setSelectedItem: (item: ResourceItem | null) => void
) => {
  const [openTabs, setOpenTabs] = useState<TabItem[]>([]);
  
  const handleCloseTab = (tabId: string) => {
    setOpenTabs(prev => prev.filter(tab => tab.id !== tabId));
    
    if (selectedItem && selectedItem.id === tabId) {
      const remainingTabs = openTabs.filter(tab => tab.id !== tabId);
      if (remainingTabs.length > 0) {
        setSelectedItem(remainingTabs[remainingTabs.length - 1].item);
      } else {
        setSelectedItem(null);
      }
    }
  };
  
  const handleSelectTab = (tabId: string) => {
    const tab = openTabs.find(t => t.id === tabId);
    if (tab) {
      setSelectedItem(tab.item);
    }
  };
  
  const addTab = (item: ResourceItem) => {
    if (!openTabs.some(tab => tab.id === item.id)) {
      setOpenTabs(prev => [...prev, { id: item.id, item }]);
    }
  };
  
  const updateTabItem = (updatedItem: ResourceItem) => {
    setOpenTabs(prev => prev.map(tab => 
      tab.id === updatedItem.id ? { ...tab, item: updatedItem } : tab
    ));
  };

  return {
    openTabs,
    handleCloseTab,
    handleSelectTab,
    addTab,
    updateTabItem
  };
};
