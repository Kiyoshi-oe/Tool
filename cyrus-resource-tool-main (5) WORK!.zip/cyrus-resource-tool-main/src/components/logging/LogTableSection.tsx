
import { LogEntry } from "../../types/fileTypes";

interface LogTableSectionProps {
  filteredEntries: LogEntry[];
  formatDate: (timestamp: number) => string;
  onRestoreVersion?: (itemId: string, timestamp: number) => void;
}

const LogTableSection = ({ 
  filteredEntries, 
  formatDate, 
  onRestoreVersion 
}: LogTableSectionProps) => {
  return (
    <div className="overflow-y-auto flex-1 p-2">
      {filteredEntries.length === 0 ? (
        <div className="text-center text-gray-400 py-8">
          No log entries found
        </div>
      ) : (
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-gray-400 uppercase">
            <tr>
              <th className="px-3 py-2">Time</th>
              <th className="px-3 py-2">Item</th>
              <th className="px-3 py-2">Field</th>
              <th className="px-3 py-2">Old Value</th>
              <th className="px-3 py-2">New Value</th>
              <th className="px-3 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredEntries.map((entry, index) => (
              <tr key={index} className="border-b border-cyrus-dark-lightest hover:bg-cyrus-dark-lighter">
                <td className="px-3 py-2 text-gray-300">{formatDate(entry.timestamp)}</td>
                <td className="px-3 py-2 text-white">{entry.itemName}</td>
                <td className="px-3 py-2 text-white">{entry.field}</td>
                <td className="px-3 py-2 text-red-400">{String(entry.oldValue)}</td>
                <td className="px-3 py-2 text-green-400">{String(entry.newValue)}</td>
                <td className="px-3 py-2">
                  {onRestoreVersion && (
                    <button 
                      className="text-xs bg-cyrus-blue hover:bg-blue-700 text-white py-1 px-2 rounded"
                      onClick={() => onRestoreVersion(entry.itemId, entry.timestamp)}
                    >
                      Restore
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default LogTableSection;
