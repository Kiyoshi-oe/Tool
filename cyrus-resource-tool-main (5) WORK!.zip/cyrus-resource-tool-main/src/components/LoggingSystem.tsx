
import { useState, useEffect } from "react";
import { LogEntry } from "../types/fileTypes";
import LogHeader from "./logging/LogHeader";
import LogFilterSection from "./logging/LogFilterSection";
import LogTableSection from "./logging/LogTableSection";

interface LoggingSystemProps {
  isVisible: boolean;
  onClose: () => void;
  logEntries: LogEntry[];
  onRestoreVersion?: (itemId: string, timestamp: number) => void;
}

const LoggingSystem = ({ isVisible, onClose, logEntries, onRestoreVersion }: LoggingSystemProps) => {
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [filteredEntries, setFilteredEntries] = useState<LogEntry[]>(logEntries);
  const [filter, setFilter] = useState('');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [filterOptions, setFilterOptions] = useState({
    itemName: '',
    field: '',
    dateFrom: '',
    dateTo: '',
    valueChanged: ''
  });

  useEffect(() => {
    // Basic filter
    let filtered = [...logEntries];
    
    if (filter) {
      filtered = filtered.filter(entry => 
        entry.itemName.toLowerCase().includes(filter.toLowerCase()) ||
        entry.field.toLowerCase().includes(filter.toLowerCase()) ||
        String(entry.oldValue).toLowerCase().includes(filter.toLowerCase()) ||
        String(entry.newValue).toLowerCase().includes(filter.toLowerCase())
      );
    }
    
    // Advanced filters
    if (showAdvancedFilters) {
      if (filterOptions.itemName) {
        filtered = filtered.filter(entry => 
          entry.itemName.toLowerCase().includes(filterOptions.itemName.toLowerCase())
        );
      }
      
      if (filterOptions.field) {
        filtered = filtered.filter(entry => 
          entry.field.toLowerCase().includes(filterOptions.field.toLowerCase())
        );
      }
      
      if (filterOptions.dateFrom) {
        const fromDate = new Date(filterOptions.dateFrom).getTime();
        filtered = filtered.filter(entry => entry.timestamp >= fromDate);
      }
      
      if (filterOptions.dateTo) {
        const toDate = new Date(filterOptions.dateTo + 'T23:59:59').getTime();
        filtered = filtered.filter(entry => entry.timestamp <= toDate);
      }
      
      if (filterOptions.valueChanged) {
        filtered = filtered.filter(entry => 
          String(entry.oldValue).includes(filterOptions.valueChanged) ||
          String(entry.newValue).includes(filterOptions.valueChanged)
        );
      }
    }
    
    // Sort
    filtered.sort((a, b) => {
      return sortOrder === 'desc' 
        ? b.timestamp - a.timestamp 
        : a.timestamp - b.timestamp;
    });
    
    setFilteredEntries(filtered);
  }, [logEntries, sortOrder, filter, filterOptions, showAdvancedFilters]);

  if (!isVisible) return null;

  const toggleSortOrder = () => {
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };
  
  const handleFilterChange = (value: string) => {
    setFilter(value);
  };
  
  const handleFilterOptionsChange = (key: keyof typeof filterOptions, value: string) => {
    setFilterOptions(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  const clearFilters = () => {
    setFilter('');
    setFilterOptions({
      itemName: '',
      field: '',
      dateFrom: '',
      dateTo: '',
      valueChanged: ''
    });
  };
  
  const handleDownloadLogs = () => {
    const json = JSON.stringify(logEntries, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'change_log.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-cyrus-dark-light rounded-lg shadow-lg w-3/4 max-h-[80vh] flex flex-col">
        <LogHeader 
          onClose={onClose}
          sortOrder={sortOrder}
          onToggleSortOrder={toggleSortOrder}
          onToggleAdvancedFilters={() => setShowAdvancedFilters(!showAdvancedFilters)}
          onDownloadLogs={handleDownloadLogs}
        />
        
        <LogFilterSection 
          filter={filter}
          onFilterChange={handleFilterChange}
          filterOptions={filterOptions}
          onFilterOptionsChange={handleFilterOptionsChange}
          showAdvancedFilters={showAdvancedFilters}
          onToggleAdvancedFilters={() => setShowAdvancedFilters(!showAdvancedFilters)}
          onClearFilters={clearFilters}
        />
        
        <LogTableSection 
          filteredEntries={filteredEntries}
          formatDate={formatDate}
          onRestoreVersion={onRestoreVersion}
        />
      </div>
    </div>
  );
};

export default LoggingSystem;
