
import { useEffect, useState } from "react";
import { ResourceItem } from "../../types/fileTypes";
import { AlertTriangle, ImageIcon } from "lucide-react";
import { Input } from "../ui/input";
import { isSupportedImageFormat, getIconPath, loadImage } from "../../utils/imageLoaders";
import { Texture } from "three";

interface VisualPropertiesSectionProps {
  localItem: ResourceItem;
  editMode: boolean;
  handleDataChange: (field: string, value: string | number | boolean) => void;
}

const VisualPropertiesSection = ({ localItem, editMode, handleDataChange }: VisualPropertiesSectionProps) => {
  const [imageError, setImageError] = useState(false);
  const [loadingImage, setLoadingImage] = useState(false);
  const [imageType, setImageType] = useState<"generic" | "dds" | "none">("none");
  const [imageElement, setImageElement] = useState<HTMLImageElement | null>(null);
  const [ddsTexture, setDdsTexture] = useState<Texture | null>(null);
  
  // Get icon name from item data and clean it
  const iconName = localItem.data.szIcon as string || '';
  const cleanedIconName = iconName.replace(/^"+|"+$/g, '');
  
  const hasIcon = cleanedIconName && isSupportedImageFormat(cleanedIconName);
  const iconPath = hasIcon ? getIconPath(cleanedIconName) : '';
  
  // Load the image based on its type when icon path changes
  useEffect(() => {
    setImageError(false);
    setImageElement(null);
    setDdsTexture(null);
    setImageType("none");
    
    if (!hasIcon || !iconPath) return;
    
    const loadIconImage = async () => {
      setLoadingImage(true);
      try {
        console.log("Loading image:", iconPath);
        const result = await loadImage(iconPath);
        
        if (!result) {
          throw new Error("Failed to load image");
        }
        
        if (result instanceof HTMLImageElement) {
          setImageElement(result);
          setImageType("generic");
          console.log("Loaded generic image successfully:", iconPath);
        } else { // Texture from DDS
          setDdsTexture(result);
          setImageType("dds");
          console.log("Loaded DDS texture successfully:", iconPath);
        }
        setImageError(false);
      } catch (error) {
        console.error(`Failed to load image ${iconPath}:`, error);
        setImageError(true);
        setImageType("none");
      } finally {
        setLoadingImage(false);
      }
    };
    
    loadIconImage();
  }, [iconPath, hasIcon]);
  
  return (
    <div className="mb-6">
      <h2 className="text-cyrus-blue text-lg font-semibold mb-2">Visual Properties</h2>
      <div className="flex items-start space-x-4 mb-4">
        <div className="form-field w-full">
          <label className="form-label">Icon</label>
          <div className="flex items-center space-x-4">
            <Input
              type="text"
              className="form-input flex-grow"
              value={iconName}
              onChange={(e) => handleDataChange('szIcon', e.target.value)}
              disabled={!editMode}
              placeholder="e.g. itm_WeaAxeCurin.dds"
            />
            <div className="border border-gray-600 bg-gray-800 w-12 h-12 flex items-center justify-center rounded overflow-hidden relative">
              {loadingImage && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-800 bg-opacity-70 z-10">
                  <div className="animate-spin h-4 w-4 border-2 border-gray-300 rounded-full border-t-transparent"></div>
                </div>
              )}
              
              {!loadingImage && imageType === "generic" && imageElement && (
                <img 
                  src={imageElement.src} 
                  alt={cleanedIconName}
                  className="max-w-full max-h-full object-contain"
                />
              )}
              
              {!loadingImage && imageType === "dds" && ddsTexture && (
                <div className="flex flex-col items-center justify-center text-xs text-green-400">
                  <ImageIcon size={16} />
                  <span>DDS</span>
                </div>
              )}
              
              {!loadingImage && imageError && (
                <div className="flex flex-col items-center justify-center text-xs text-red-400">
                  <AlertTriangle size={16} />
                  <span>Error</span>
                </div>
              )}
              
              {!loadingImage && imageType === "none" && !imageError && !hasIcon && (
                <span className="text-xs text-gray-500">No icon</span>
              )}
            </div>
          </div>
          {iconName && !isSupportedImageFormat(iconName) && (
            <p className="text-xs text-yellow-500 mt-1">
              Unsupported file format. Supported formats: PNG, JPG, JPEG, GIF, BMP, WEBP, DDS
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default VisualPropertiesSection;
