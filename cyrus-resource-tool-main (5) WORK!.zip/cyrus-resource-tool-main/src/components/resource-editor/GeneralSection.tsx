
import { ResourceItem } from "../../types/fileTypes";
import { ChevronDown } from "lucide-react";
import { Input } from "../ui/input";
import { itemKind1Options, itemKind2Options, itemKind3Options, jobOptions } from "../../utils/resourceEditorUtils";
import { FormField } from "../ui/form-field";
import { Textarea } from "../ui/textarea";

interface GeneralSectionProps {
  localItem: ResourceItem;
  editMode: boolean;
  handleDataChange: (field: string, value: string | number | boolean) => void;
}

const GeneralSection = ({ localItem, editMode, handleDataChange }: GeneralSectionProps) => {
  // The ID from propItem.txt.txt (e.g. IDS_PROPITEM_TXT_000124)
  const propItemId = localItem.data.szName as string || '';
  
  // Get the actual display name from the item 
  const displayName = localItem.displayName || propItemId;
  
  // Get the description (which was loaded from propItem.txt.txt)
  const description = localItem.description || 'No description available';
  
  console.log("GeneralSection rendering with propItemId:", propItemId);
  console.log("Display name:", displayName);
  console.log("Description:", description);
  
  return (
    <div className="mb-6">
      <h2 className="text-cyrus-blue text-lg font-semibold mb-2">General</h2>
      <div className="grid grid-cols-2 gap-4">
        <div className="form-field">
          <label className="form-label">ID</label>
          <Input
            type="text"
            className="form-input"
            value={localItem.data.dwID as string || ''}
            onChange={(e) => handleDataChange('dwID', e.target.value)}
            disabled={!editMode}
          />
        </div>
        
        <div className="form-field">
          <label className="form-label">ID PropItem</label>
          <Input
            type="text"
            className="form-input"
            value={propItemId}
            onChange={(e) => handleDataChange('szName', e.target.value)}
            disabled={!editMode}
          />
        </div>
        
        <div className="form-field">
          <label className="form-label">Name</label>
          <Input
            type="text"
            className="form-input"
            value={displayName}
            onChange={(e) => handleDataChange('displayName', e.target.value)}
            disabled={!editMode}
          />
        </div>
        
        <div className="form-field col-span-2">
          <label className="form-label">Description</label>
          <Textarea
            className="form-input h-20 resize-y"
            value={description}
            onChange={(e) => handleDataChange('description', e.target.value)}
            disabled={!editMode}
            placeholder="Item description"
          />
        </div>
        
        <div className="form-field">
          <label className="form-label">Item Kind 1</label>
          <div className="relative">
            <select
              className="form-input appearance-none pr-10"
              value={localItem.data.dwItemKind1 as string || ''}
              onChange={(e) => handleDataChange('dwItemKind1', e.target.value)}
              disabled={!editMode}
            >
              {itemKind1Options.map(option => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-2.5 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
        
        <div className="form-field">
          <label className="form-label">Item Kind 2</label>
          <div className="relative">
            <select
              className="form-input appearance-none pr-10"
              value={localItem.data.dwItemKind2 as string || ''}
              onChange={(e) => handleDataChange('dwItemKind2', e.target.value)}
              disabled={!editMode}
            >
              {itemKind2Options.map(option => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-2.5 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
        
        <div className="form-field">
          <label className="form-label">Item Kind 3</label>
          <div className="relative">
            <select
              className="form-input appearance-none pr-10"
              value={localItem.data.dwItemKind3 as string || ''}
              onChange={(e) => handleDataChange('dwItemKind3', e.target.value)}
              disabled={!editMode}
            >
              {itemKind3Options.map(option => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-2.5 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
        
        <div className="form-field">
          <label className="form-label">Job / Class</label>
          <div className="relative">
            <select
              className="form-input appearance-none pr-10"
              value={localItem.data.dwItemJob as string || ''}
              onChange={(e) => handleDataChange('dwItemJob', e.target.value)}
              disabled={!editMode}
            >
              {jobOptions.map(option => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-2.5 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
        
        <div className="form-field">
          <label className="form-label">Required Level</label>
          <Input
            type="number"
            className="form-input"
            value={localItem.data.dwLimitLevel1 as string || '0'}
            onChange={(e) => handleDataChange('dwLimitLevel1', e.target.value)}
            disabled={!editMode}
          />
        </div>
        
        <div className="form-field">
          <label className="form-label">Tradable</label>
          <div className="flex items-center space-x-4 mt-2">
            <label className="flex items-center space-x-2">
              <input
                type="radio"
                className="form-radio"
                name="tradable"
                checked={localItem.data.bPermanence === "0"}
                onChange={() => handleDataChange('bPermanence', "0")}
                disabled={!editMode}
              />
              <span className="text-sm text-gray-300">No</span>
            </label>
            <label className="flex items-center space-x-2">
              <input
                type="radio"
                className="form-radio"
                name="tradable"
                checked={localItem.data.bPermanence === "1"}
                onChange={() => handleDataChange('bPermanence', "1")}
                disabled={!editMode}
              />
              <span className="text-sm text-gray-300">Yes</span>
            </label>
          </div>
        </div>
        
        <div className="form-field">
          <label className="form-label">Stack Size</label>
          <Input
            type="number"
            className="form-input"
            value={localItem.data.dwPackMax as string || '1'}
            onChange={(e) => handleDataChange('dwPackMax', e.target.value)}
            disabled={!editMode}
          />
        </div>
        
        <div className="form-field">
          <label className="form-label">Gold Value</label>
          <Input
            type="number"
            className="form-input"
            value={localItem.data.dwCost as string || '0'}
            onChange={(e) => handleDataChange('dwCost', e.target.value)}
            disabled={!editMode}
          />
        </div>
      </div>
    </div>
  );
};

export default GeneralSection;
