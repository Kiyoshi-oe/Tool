
// Method to serialize the file data back to text format
export const serializeToText = (fileData: any): string => {
  const headerLine = fileData.header.map((col: string) => `${col}`).join("\t");
  
  const dataLines = fileData.items.map((item: any) => {
    // Ensure we output ALL columns in the correct order
    const values = fileData.header.map((col: string) => {
      return item.data[col] !== undefined ? item.data[col] : "=";
    });
    
    return values.join("\t");
  });
  
  return [headerLine, ...dataLines].join("\n");
};

// Special function to serialize propItem.txt.txt data
export const serializePropItemData = (items: any[]): string => {
  const lines: string[] = [];
  
  items.forEach(item => {
    if (!item.name || !item.idPropItem) return;
    
    // Get the base ID from the item's propItem ID
    const idMatch = item.idPropItem.match(/IDS_PROPITEM_TXT_(\d+)/);
    if (!idMatch) return;
    
    const baseId = parseInt(idMatch[1], 10);
    if (isNaN(baseId)) return;
    
    // Add the name entry (even number)
    const nameId = `IDS_PROPITEM_TXT_${baseId.toString().padStart(6, '0')}`;
    lines.push(`${nameId}\t${item.displayName || item.name}`);
    
    // Add the description entry (odd number = baseId + 1)
    const descId = `IDS_PROPITEM_TXT_${(baseId + 1).toString().padStart(6, '0')}`;
    lines.push(`${descId}\t${item.description || ''}`);
  });
  
  return lines.join("\n");
};

// Track modified files that need to be saved
let modifiedFiles: { name: string; content: string }[] = [];

// Add or update a file in the modified files list
export const trackModifiedFile = (fileName: string, content: string) => {
  const existingIndex = modifiedFiles.findIndex(file => file.name === fileName);
  
  if (existingIndex >= 0) {
    modifiedFiles[existingIndex].content = content;
  } else {
    modifiedFiles.push({ name: fileName, content });
  }
  
  console.log(`Tracked modified file: ${fileName}`);
  return modifiedFiles;
};

// Track changes to propItem entries (names and descriptions)
export const trackPropItemChanges = (itemId: string, itemName: string, displayName: string, description: string) => {
  // We'll collect all propItem changes and then serialize them when saving
  // Mark the propItem.txt.txt file as modified with a placeholder
  trackModifiedFile("propItem.txt.txt", `PENDING_CHANGES_FOR_${itemId}`);
  console.log(`Tracked propItem changes for ${itemName}: "${displayName}" / "${description.substring(0, 30)}..."`);
};

// Save all propItem changes to the propItem.txt.txt file
export const savePropItemChanges = async (items: any[]): Promise<boolean> => {
  if (!items || items.length === 0) return false;
  
  // Only process if we have pending propItem changes
  const hasPropItemChanges = modifiedFiles.some(file => file.name === "propItem.txt.txt");
  if (!hasPropItemChanges) return true;
  
  try {
    console.log("Serializing propItem changes for", items.length, "items");
    
    // First load the existing propItem.txt.txt file to preserve existing entries
    let existingContent = "";
    
    try {
      const response = await fetch('/public/resource/propItem.txt.txt');
      if (response.ok) {
        existingContent = await response.text();
        console.log("Loaded existing propItem.txt.txt, content length:", existingContent.length);
      } else {
        console.warn("Could not load existing propItem.txt.txt, will create new file");
      }
    } catch (error) {
      console.warn("Error loading existing propItem.txt.txt:", error);
    }
    
    // Now serialize our changed items
    const serializedChanges = serializePropItemData(items);
    
    // If we have existing content, we need to merge the changes
    let finalContent = serializedChanges;
    if (existingContent) {
      // For simplicity, we'll just append our changes
      // In a real implementation, you would parse the existing file and update specific entries
      finalContent = existingContent + "\n" + serializedChanges;
    }
    
    // Update the tracked file with the actual content
    const existingIndex = modifiedFiles.findIndex(file => file.name === "propItem.txt.txt");
    if (existingIndex >= 0) {
      modifiedFiles[existingIndex].content = finalContent;
    }
    
    return true;
  } catch (error) {
    console.error("Error serializing propItem changes:", error);
    return false;
  }
};

// Get the list of modified files
export const getModifiedFiles = () => {
  return [...modifiedFiles];
};

// Clear the list of modified files
export const clearModifiedFiles = () => {
  modifiedFiles = [];
};

// Save a single file
export const saveTextFile = (content: string, fileName: string): Promise<boolean> => {
  return new Promise(async (resolve) => {
    // Track the file modification
    trackModifiedFile(fileName, content);
    
    // Check if we're in Electron environment
    const isElectron = window.navigator.userAgent.toLowerCase().indexOf('electron') > -1;
    
    if (isElectron) {
      try {
        console.log("Electron environment detected, attempting direct save");
        
        // First try to save via the electronAPI
        if ((window as any).electronAPI) {
          console.log("Using electronAPI.saveFile");
          const result = await (window as any).electronAPI.saveFile(fileName, content, './public/resource');
          
          if (result.success) {
            console.log(`File saved directly to resource folder via Electron API: ${result.path}`);
            resolve(true);
            return;
          } else {
            console.error("Error saving via Electron API:", result.error);
          }
        } else {
          // Fallback to custom event for older versions
          console.log("Fallback to custom event for Electron");
          const event = new CustomEvent('save-file', { 
            detail: { 
              fileName, 
              content, 
              path: './public/resource' 
            }
          });
          window.dispatchEvent(event);
          
          // Listen for the response from Electron
          const responseHandler = (event: any) => {
            const response = event.detail;
            console.log("Save response from Electron:", response);
            if (response.success) {
              console.log(`File saved directly to resource folder via Electron: ${fileName}`);
              window.removeEventListener('save-file-response', responseHandler);
              resolve(true);
            } else {
              console.error("Error saving via Electron:", response.error);
              window.removeEventListener('save-file-response', responseHandler);
              // Fall back to server-side save
              attemptServerSave();
            }
          };
          
          window.addEventListener('save-file-response', responseHandler, { once: true });
          
          // Set a timeout in case Electron doesn't respond
          setTimeout(() => {
            console.warn("No response from Electron after 2 seconds, falling back to server-side save");
            window.removeEventListener('save-file-response', responseHandler);
            attemptServerSave();
          }, 2000);
          
          return;
        }
      } catch (error) {
        console.error("Error using Electron save API:", error);
        // Fall back to server-side save if Electron API fails
      }
    }
    
    // If not in Electron or Electron save failed, try server-side save
    attemptServerSave();
    
    async function attemptServerSave() {
      try {
        const success = await saveToResourceFolder(content, fileName);
        if (success) {
          console.log(`File saved to server resource folder: ${fileName}`);
          resolve(true);
          return;
        }
        
        // If server-side save fails, fall back to download
        console.warn("Server-side save failed, falling back to download");
        downloadTextFile(content, fileName);
        resolve(false);
      } catch (error) {
        console.error("Error during server-side save:", error);
        downloadTextFile(content, fileName);
        resolve(false);
      }
    }
  });
};

// Save all modified files at once
export const saveAllModifiedFiles = async (): Promise<boolean> => {
  const filesToSave = getModifiedFiles();
  
  if (filesToSave.length === 0) {
    console.log("No modified files to save");
    return true;
  }
  
  console.log(`Saving ${filesToSave.length} modified files:`, filesToSave.map(f => f.name).join(', '));
  
  // Check if we're in Electron environment
  const isElectron = window.navigator.userAgent.toLowerCase().indexOf('electron') > -1;
  
  if (isElectron) {
    try {
      if ((window as any).electronAPI) {
        console.log("Using electronAPI.saveAllFiles");
        const result = await (window as any).electronAPI.saveAllFiles(filesToSave);
        
        if (result.success) {
          console.log(`All files saved successfully via Electron API`);
          clearModifiedFiles();
          return true;
        } else {
          console.error("Error saving all files via Electron API:", result.error);
        }
      } else {
        // Fallback to custom event
        console.log("Using custom event for saveAllFiles");
        const event = new CustomEvent('save-all-files', { 
          detail: { files: filesToSave }
        });
        window.dispatchEvent(event);
        
        return new Promise((resolve) => {
          const responseHandler = (event: any) => {
            const response = event.detail;
            console.log("Save all files response:", response);
            if (response.success) {
              console.log(`All files saved successfully via Electron`);
              clearModifiedFiles();
              window.removeEventListener('save-all-files-response', responseHandler);
              resolve(true);
            } else {
              console.error("Error saving all files via Electron:", response.error);
              window.removeEventListener('save-all-files-response', responseHandler);
              resolve(false);
            }
          };
          
          window.addEventListener('save-all-files-response', responseHandler, { once: true });
          
          // Set a timeout in case Electron doesn't respond
          setTimeout(() => {
            console.warn("No response from Electron after 2 seconds");
            window.removeEventListener('save-all-files-response', responseHandler);
            resolve(false);
          }, 2000);
        });
      }
    } catch (error) {
      console.error("Error using Electron saveAllFiles API:", error);
    }
  }
  
  // Try server-side save for all files
  try {
    const success = await saveMultipleFilesToResourceFolder(filesToSave);
    if (success) {
      console.log("All files saved to server resource folder");
      clearModifiedFiles();
      return true;
    }
  } catch (error) {
    console.error("Error during server-side batch save:", error);
  }
  
  // If all else fails, fall back to individual saves
  console.warn("Batch save failed, falling back to individual file saves");
  let allSuccessful = true;
  
  for (const file of filesToSave) {
    try {
      const success = await saveTextFile(file.content, file.name);
      if (!success) {
        allSuccessful = false;
      }
    } catch (error) {
      console.error(`Error saving file ${file.name}:`, error);
      allSuccessful = false;
    }
  }
  
  if (allSuccessful) {
    clearModifiedFiles();
  }
  
  return allSuccessful;
};

// Improved server-side save function with better error handling
const saveToResourceFolder = async (content: string, fileName: string): Promise<boolean> => {
  try {
    console.log(`Attempting to save ${fileName} to resource folder via server API`);
    
    // Attempt to save the file to the server's resource folder
    const response = await fetch('/api/save-resource', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fileName,
        content,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error(`Server responded with ${response.status}:`, errorData);
      return false;
    }

    const result = await response.json();
    return result.success === true;
  } catch (error) {
    console.error("Failed to save file to resource folder:", error);
    return false;
  }
};

// Save multiple files to resource folder at once
const saveMultipleFilesToResourceFolder = async (files: { name: string; content: string }[]): Promise<boolean> => {
  try {
    console.log(`Attempting to save ${files.length} files to resource folder via server API`);
    
    const response = await fetch('/api/save-resource', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ files }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error(`Server responded with ${response.status}:`, errorData);
      return false;
    }

    const result = await response.json();
    console.log("Server save result:", result);
    
    return result.success === true;
  } catch (error) {
    console.error("Failed to save multiple files to resource folder:", error);
    return false;
  }
};

// Standard browser download method (fallback)
const downloadTextFile = (content: string, fileName: string): void => {
  console.log("Falling back to browser download for", fileName);
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName;
  link.click();
  
  URL.revokeObjectURL(url);
};

export const readTextFile = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    // For large files, use the chunked approach
    if (file.size > 10 * 1024 * 1024) { // If file is larger than 10MB
      const CHUNK_SIZE = 15 * 1024 * 1024; // 15MB chunks for faster processing
      let content = "";
      let offset = 0;
      const fileSize = file.size;
      
      const readNextChunk = () => {
        const reader = new FileReader();
        const chunk = file.slice(offset, offset + CHUNK_SIZE);
        
        reader.onload = (e) => {
          if (e.target?.result) {
            content += e.target.result;
            offset += CHUNK_SIZE;
            
            if (offset < fileSize) {
              readNextChunk();
            } else {
              resolve(content);
            }
          }
        };
        
        reader.onerror = () => {
          reject(new Error("Error reading file chunk"));
        };
        
        reader.readAsText(chunk);
      };
      
      readNextChunk();
    } else {
      // For smaller files, use the standard approach
      const reader = new FileReader();
      
      reader.onload = (event) => {
        if (event.target?.result) {
          resolve(event.target.result as string);
        } else {
          reject(new Error("Failed to read file"));
        }
      };
      
      reader.onerror = () => {
        reject(new Error("File read error"));
      };
      
      reader.readAsText(file);
    }
  });
};
