
import { useState } from "react";
import { LogEntry } from "../../types/fileTypes";
import { ChevronDown, ChevronUp, RefreshCw } from "lucide-react";

interface LogAccordionGroupProps {
  entries: LogEntry[];
  title: string;
  formatDate: (timestamp: number) => string;
  onRestoreVersion?: (itemId: string, timestamp: number) => void;
}

const LogAccordionGroup = ({ entries, title, formatDate, onRestoreVersion }: LogAccordionGroupProps) => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="border border-gray-700 rounded-md mb-2 overflow-hidden">
      <div 
        className="flex items-center justify-between p-3 bg-cyrus-dark-lighter cursor-pointer"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex items-center">
          {isOpen ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          <span className="ml-2 font-medium">{title} ({entries.length})</span>
        </div>
      </div>
      
      {isOpen && (
        <div className="bg-cyrus-dark">
          <table className="w-full border-collapse">
            <thead className="bg-cyrus-dark-lighter">
              <tr className="text-xs uppercase">
                <th className="p-2 text-left">Time</th>
                <th className="p-2 text-left">Field</th>
                <th className="p-2 text-left">Old Value</th>
                <th className="p-2 text-left">New Value</th>
                <th className="p-2 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {entries.map((entry, index) => (
                <tr 
                  key={index}
                  className="border-t border-gray-800 text-sm hover:bg-cyrus-dark-lighter"
                >
                  <td className="p-2 text-gray-300">{formatDate(entry.timestamp)}</td>
                  <td className="p-2">{entry.field}</td>
                  <td className="p-2 text-red-400">{String(entry.oldValue).substring(0, 30)}{String(entry.oldValue).length > 30 ? '...' : ''}</td>
                  <td className="p-2 text-green-400">{String(entry.newValue).substring(0, 30)}{String(entry.newValue).length > 30 ? '...' : ''}</td>
                  <td className="p-2 text-center">
                    {onRestoreVersion && (
                      <button
                        onClick={() => onRestoreVersion(entry.itemId, entry.timestamp)}
                        className="text-[#007BFF] hover:text-[#0056b3] focus:outline-none"
                        title="Restore to this version"
                      >
                        <RefreshCw size={16} />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

interface LogTableSectionProps {
  filteredEntries: LogEntry[];
  formatDate: (timestamp: number) => string;
  onRestoreVersion?: (itemId: string, timestamp: number) => void;
}

const LogTableSection = ({ filteredEntries, formatDate, onRestoreVersion }: LogTableSectionProps) => {
  // Group entries by itemName
  const groupedEntries: Record<string, LogEntry[]> = {};
  
  filteredEntries.forEach(entry => {
    const key = entry.itemName || entry.itemId || 'Unknown Item';
    
    if (!groupedEntries[key]) {
      groupedEntries[key] = [];
    }
    
    groupedEntries[key].push(entry);
  });
  
  return (
    <div className="flex-1 overflow-y-auto p-4">
      {Object.keys(groupedEntries).length === 0 ? (
        <div className="text-center p-8 text-gray-400">
          No log entries found with the current filters
        </div>
      ) : (
        Object.entries(groupedEntries).map(([itemName, entries]) => (
          <LogAccordionGroup
            key={itemName}
            title={itemName}
            entries={entries}
            formatDate={formatDate}
            onRestoreVersion={onRestoreVersion}
          />
        ))
      )}
    </div>
  );
};

export default LogTableSection;
