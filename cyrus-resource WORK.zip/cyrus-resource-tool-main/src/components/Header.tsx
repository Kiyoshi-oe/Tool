
import { Star, MinusCircle, X, Square, Settings, FileText, List, FileQuestion, Home, Save, Eye, Edit } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";
import FileMenu from "./FileMenu";

interface HeaderProps {
  title: string;
  currentTab: string;
  currentItem?: string;
  onSave: () => void;
  onShowSettings: () => void;
  onShowLogging: () => void;
  onFileMenuToggle: () => void;
  showFileMenu: boolean;
  onShowAbout: () => void;
  onShowToDo: () => void;
  onShowHome: () => void;
  darkMode?: boolean;
  editMode?: boolean;
  onToggleEditMode: () => void;
}

const Header = ({ 
  title, 
  currentTab, 
  currentItem, 
  onSave, 
  onShowSettings,
  onShowLogging,
  onFileMenuToggle,
  showFileMenu,
  onShowAbout,
  onShowToDo,
  onShowHome,
  darkMode = true,
  editMode = false,
  onToggleEditMode
}: HeaderProps) => {
  
  return (
    <div className={`flex items-center justify-between px-4 py-2 ${darkMode ? 'bg-cyrus-dark' : 'bg-gray-200'} border-b ${darkMode ? 'border-cyrus-dark-lightest' : 'border-gray-300'}`}>
      <div className="flex items-center space-x-2">
        <img 
          src="/lovable-uploads/icon_small.png" 
          alt="Cyrus" 
          className="w-5 h-5" 
        />
        <div className="flex items-center space-x-4">
          <FileMenu
            onOpen={() => {
              onFileMenuToggle();
              toast.info("Opening file selector");
            }}
            onSave={onSave}
            onSaveAs={(fileName) => {
              onFileMenuToggle();
              toast.info(`Saving as ${fileName}`);
            }}
            editMode={editMode}
            onToggleEditMode={onToggleEditMode}
          />
          
          <button 
            className={`px-2 py-1 text-sm ${darkMode ? 'text-gray-300 hover:text-white hover:bg-cyrus-dark-lighter' : 'text-gray-700 hover:text-black hover:bg-gray-300'} flex items-center space-x-1 rounded`}
            onClick={onShowHome}
          >
            <Home size={14} />
            <span>Home</span>
          </button>
          
          <button 
            className={`px-2 py-1 text-sm ${darkMode ? 'text-gray-300 hover:text-white hover:bg-cyrus-dark-lighter' : 'text-gray-700 hover:text-black hover:bg-gray-300'} flex items-center space-x-1 rounded`}
            onClick={onShowSettings}
          >
            <Settings size={14} />
            <span>Settings</span>
          </button>
          
          <button 
            className={`px-2 py-1 text-sm ${darkMode ? 'text-gray-300 hover:text-white hover:bg-cyrus-dark-lighter' : 'text-gray-700 hover:text-black hover:bg-gray-300'} flex items-center space-x-1 rounded`}
            onClick={onShowLogging}
          >
            <FileText size={14} />
            <span>Logging</span>
          </button>
          
          <button 
            className={`px-2 py-1 text-sm ${darkMode ? 'text-gray-300 hover:text-white hover:bg-cyrus-dark-lighter' : 'text-gray-700 hover:text-black hover:bg-gray-300'} flex items-center space-x-1 rounded`}
            onClick={onShowToDo}
          >
            <List size={14} />
            <span>To-Do</span>
          </button>
          
          <button 
            className={`px-2 py-1 text-sm ${darkMode ? 'text-gray-300 hover:text-white hover:bg-cyrus-dark-lighter' : 'text-gray-700 hover:text-black hover:bg-gray-300'} flex items-center space-x-1 rounded`}
            onClick={onShowAbout}
          >
            <FileQuestion size={14} />
            <span>About</span>
          </button>
        </div>
      </div>
      
      <div className={`text-center ${darkMode ? 'text-white' : 'text-gray-800'}`}>
        {currentTab}{currentItem ? ` - ${currentItem}` : ''} {currentItem ? `- ${editMode ? 'Edit' : 'View'}` : ''}
      </div>
      
      <div className="flex items-center space-x-2">
        <button className={`${darkMode ? 'text-[#ffcc33] hover:text-[#ffdd66]' : 'text-[#ff9900] hover:text-[#ffbb44]'}`}>
          <MinusCircle size={18} />
        </button>
        <button className={`${darkMode ? 'text-[#33cc33] hover:text-[#44dd44]' : 'text-[#00cc00] hover:text-[#22dd22]'}`}>
          <Square size={18} />
        </button>
        <button 
          className={`${darkMode ? 'text-[#ff3333] hover:text-[#ff4444]' : 'text-[#cc0000] hover:text-[#dd2222]'}`}
          onClick={() => toast.info("Close button clicked")}
        >
          <X size={18} />
        </button>
      </div>
    </div>
  );
};

export default Header;
