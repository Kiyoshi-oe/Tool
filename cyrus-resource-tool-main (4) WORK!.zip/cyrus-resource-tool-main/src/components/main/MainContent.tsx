
import ResourceEditor from "../ResourceEditor";
import SettingsPanel from "../SettingsPanel";
import ToDoPanel from "../ToDoPanel";
import { ResourceItem } from "../../types/fileTypes";
import { Redo, Undo } from "lucide-react";

interface MainContentProps {
  showSettings: boolean;
  showToDoPanel: boolean;
  selectedItem: ResourceItem | null;
  handleUpdateItem: (item: ResourceItem) => void;
  editMode: boolean;
  undoStack: any[];
  redoStack: any[];
  handleUndo: () => void;
  handleRedo: () => void;
  settings: any;
  setSettings: (settings: any) => void;
  fileData: any;
  currentTab: string;
  themes: any[];
  fontOptions: any[];
  currentTheme: any;
  onShowFileUpload?: () => void;
  onShowSettings?: () => void;
}

const MainContent = ({
  showSettings,
  showToDoPanel,
  selectedItem,
  handleUpdateItem,
  editMode,
  undoStack,
  redoStack,
  handleUndo,
  handleRedo,
  settings,
  setSettings,
  fileData,
  currentTab,
  themes,
  fontOptions,
  currentTheme,
  onShowFileUpload,
  onShowSettings
}: MainContentProps) => {
  return (
    <>
      {showSettings ? (
        <SettingsPanel 
          settings={settings}
          onSaveSettings={setSettings}
          fontOptions={fontOptions}
          themes={themes}
        />
      ) : showToDoPanel ? (
        <ToDoPanel />
      ) : selectedItem ? (
        <>
          <div 
            className="flex items-center px-4 py-1 space-x-2"
            style={{
              backgroundColor: currentTheme.buttonBg || (settings.darkMode ? '#2D2D30' : '#F1F1F1')
            }}
          >
            <button 
              className="p-1 rounded"
              style={{
                color: undoStack.length > 0 
                  ? currentTheme.foreground || '#FFFFFF'
                  : '#777777',
                backgroundColor: 'transparent',
                cursor: undoStack.length > 0 ? 'pointer' : 'not-allowed'
              }}
              onClick={handleUndo}
              disabled={undoStack.length === 0}
              title="Undo"
              type="button"
            >
              <Undo size={16} />
            </button>
            <button 
              className="p-1 rounded"
              style={{
                color: redoStack.length > 0 
                  ? currentTheme.foreground || '#FFFFFF'
                  : '#777777',
                backgroundColor: 'transparent',
                cursor: redoStack.length > 0 ? 'pointer' : 'not-allowed'
              }}
              onClick={handleRedo}
              disabled={redoStack.length === 0}
              title="Redo"
              type="button"
            >
              <Redo size={16} />
            </button>
            <div 
              className="text-xs"
              style={{
                color: currentTheme.isDark ? '#BBBBBB' : '#666666'
              }}
            >
              Editing: {selectedItem.displayName || selectedItem.data.szName as string}
            </div>
          </div>
          <ResourceEditor 
            item={selectedItem}
            onUpdateItem={handleUpdateItem}
            editMode={editMode}
          />
        </>
      ) : (
        <WelcomeScreen 
          fileData={fileData}
          currentTab={currentTab}
          currentTheme={currentTheme}
          settings={settings}
          onShowFileUpload={onShowFileUpload}
          onShowSettings={onShowSettings}
        />
      )}
    </>
  );
};

// Define WelcomeScreen as a separate component
const WelcomeScreen = ({ 
  fileData, 
  currentTab, 
  currentTheme, 
  settings,
  onShowFileUpload,
  onShowSettings
}: any) => {
  return (
    <div 
      className="flex-1 flex items-center justify-center p-4"
      style={{
        backgroundColor: currentTheme.background || (settings.darkMode ? '#1E1E1E' : '#FAFAFA')
      }}
    >
      {fileData ? (
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">
            File loaded successfully! ({fileData.items.length} items)
          </h2>
          <p className="mb-4">
            Select an item type using the tabs above, then select an item from the sidebar to edit it.
          </p>
        </div>
      ) : (
        <div className="text-center max-w-2xl">
          <div className="flex justify-center mb-6">
            <img 
              src="/lovable-uploads/fb52f3a5-7dc6-4160-9fa1-1267aa92ece4.png" 
              alt="Cyrus Resource Tool" 
              className="w-64 h-auto"
            />
          </div>
          <h1 
            className="text-3xl font-semibold mb-4"
            style={{
              color: currentTheme.accent || (settings.darkMode ? '#FFC940' : '#0078D7')
            }}
          >
            Welcome to the Cyrus Resource Tool
          </h1>
          <p 
            className="mb-8"
            style={{
              color: currentTheme.foreground || (settings.darkMode ? '#CCCCCC' : '#333333')
            }}
          >
            This tool was developed to make resource work much faster.<br />
            You can customize each item and its settings, with the possibility to add new items.
          </p>
          
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 justify-center">
            <button 
              type="button"
              className="py-2 px-6 rounded transition-colors"
              style={{
                backgroundColor: currentTheme.accent || '#0078D7',
                color: '#FFFFFF'
              }}
              onClick={onShowFileUpload}
            >
              Load Resource File
            </button>
            <button 
              type="button"
              className="py-2 px-6 rounded transition-colors"
              style={{
                backgroundColor: currentTheme.accent || '#0078D7',
                color: '#FFFFFF'
              }}
              onClick={() => {
                if (typeof window !== "undefined") {
                  // Create file input element
                  const fileInput = document.createElement("input");
                  fileInput.type = "file";
                  fileInput.multiple = true;
                  fileInput.accept = ".txt,.h,.inc";
                  fileInput.style.display = "none";
                  
                  // Add to body and trigger click
                  document.body.appendChild(fileInput);
                  fileInput.click();
                  
                  // Handle file selection
                  fileInput.onchange = (event) => {
                    const files = fileInput.files;
                    if (files && files.length > 0) {
                      // Show a message
                      console.log("Custom files selected:", files);
                      
                      // Here you would need to handle the file loading
                      // For now, just trigger the normal upload modal
                      if (onShowFileUpload) onShowFileUpload();
                    }
                    
                    // Clean up
                    document.body.removeChild(fileInput);
                  };
                }
              }}
            >
              Upload Custom Files
            </button>
            <button 
              type="button"
              className="py-2 px-6 rounded transition-colors"
              style={{
                backgroundColor: currentTheme.buttonBg || (settings.darkMode ? '#252526' : '#F1F1F1'),
                color: currentTheme.foreground || (settings.darkMode ? '#FFFFFF' : '#1D1D1F')
              }}
              onClick={onShowSettings}
            >
              Settings
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default MainContent;
export { WelcomeScreen };
