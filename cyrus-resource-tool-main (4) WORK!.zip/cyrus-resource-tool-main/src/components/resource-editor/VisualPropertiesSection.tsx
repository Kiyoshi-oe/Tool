
import { useEffect, useState } from "react";
import { ResourceItem } from "../../types/fileTypes";
import { AlertTriangle } from "lucide-react";
import { Input } from "../ui/input";
import { isSupportedImageFormat, getIconPath } from "../../utils/resourceEditorUtils";

interface VisualPropertiesSectionProps {
  localItem: ResourceItem;
  editMode: boolean;
  handleDataChange: (field: string, value: string | number | boolean) => void;
}

const VisualPropertiesSection = ({ localItem, editMode, handleDataChange }: VisualPropertiesSectionProps) => {
  const [imageError, setImageError] = useState(false);
  
  // Get icon name from item data and clean it
  const iconName = localItem.data.szIcon as string || '';
  const cleanedIconName = iconName.replace(/["""]/g, '');
  
  // Reset the error state when the icon name changes
  useEffect(() => {
    setImageError(false);
  }, [cleanedIconName]);
  
  const hasIcon = cleanedIconName && isSupportedImageFormat(cleanedIconName);
  const iconPath = hasIcon ? getIconPath(cleanedIconName) : '';
  
  console.log("Icon path:", iconPath, "Icon name:", cleanedIconName, "Has icon:", hasIcon);
  
  return (
    <div className="mb-6">
      <h2 className="text-cyrus-blue text-lg font-semibold mb-2">Visual Properties</h2>
      <div className="flex items-start space-x-4 mb-4">
        <div className="form-field w-full">
          <label className="form-label">Icon</label>
          <div className="flex items-center space-x-4">
            <Input
              type="text"
              className="form-input flex-grow"
              value={iconName}
              onChange={(e) => handleDataChange('szIcon', e.target.value)}
              disabled={!editMode}
              placeholder="e.g. itm_WeaAxeCurin.dds"
            />
            <div className="border border-gray-600 bg-gray-800 w-12 h-12 flex items-center justify-center rounded overflow-hidden">
              {hasIcon ? (
                imageError ? (
                  <div className="flex flex-col items-center justify-center text-xs text-red-400">
                    <AlertTriangle size={16} />
                    <span>Error</span>
                  </div>
                ) : (
                  <img 
                    src={iconPath} 
                    alt={cleanedIconName}
                    className="max-w-full max-h-full object-contain" 
                    onError={() => {
                      console.error(`Failed to load icon: ${iconPath}`);
                      setImageError(true);
                    }}
                    onLoad={() => {
                      console.log(`Successfully loaded icon: ${iconPath}`);
                      setImageError(false);
                    }}
                  />
                )
              ) : (
                <span className="text-xs text-gray-500">No icon</span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VisualPropertiesSection;
