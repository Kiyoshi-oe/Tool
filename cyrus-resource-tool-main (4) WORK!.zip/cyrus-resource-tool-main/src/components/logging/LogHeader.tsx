
import { X, Download, ArrowUpDown, Filter } from "lucide-react";

interface LogHeaderProps {
  onClose: () => void;
  sortOrder: 'asc' | 'desc';
  onToggleSortOrder: () => void;
  onToggleAdvancedFilters: () => void;
  onDownloadLogs: () => void;
}

const LogHeader = ({ 
  onClose, 
  sortOrder, 
  onToggleSortOrder, 
  onToggleAdvancedFilters,
  onDownloadLogs 
}: LogHeaderProps) => {
  return (
    <div className="flex items-center justify-between bg-cyrus-dark-lighter p-4 rounded-t-lg">
      <h2 className="text-xl font-semibold text-cyrus-gold">Change Log</h2>
      <div className="flex items-center space-x-4">
        <button 
          className="text-gray-400 hover:text-white flex items-center space-x-1"
          onClick={onToggleSortOrder}
        >
          <ArrowUpDown size={16} />
          <span className="text-sm">{sortOrder === 'desc' ? 'Newest First' : 'Oldest First'}</span>
        </button>
        <button 
          className="text-gray-400 hover:text-white flex items-center space-x-1"
          onClick={onToggleAdvancedFilters}
        >
          <Filter size={16} />
          <span className="text-sm">Filters</span>
        </button>
        <button 
          className="text-gray-400 hover:text-white"
          onClick={onDownloadLogs}
        >
          <Download size={18} />
        </button>
        <button 
          className="text-gray-400 hover:text-white"
          onClick={onClose}
        >
          <X size={18} />
        </button>
      </div>
    </div>
  );
};

export default LogHeader;
