
import { Search, Filter } from "lucide-react";
import { useState } from "react";

interface FilterOptions {
  itemName: string;
  field: string;
  dateFrom: string;
  dateTo: string;
  valueChanged: string;
}

interface LogFilterSectionProps {
  filter: string;
  onFilterChange: (value: string) => void;
  filterOptions: FilterOptions;
  onFilterOptionsChange: (key: keyof FilterOptions, value: string) => void;
  showAdvancedFilters: boolean;
  onToggleAdvancedFilters: () => void;
  onClearFilters: () => void;
}

const LogFilterSection = ({
  filter,
  onFilterChange,
  filterOptions,
  onFilterOptionsChange,
  showAdvancedFilters,
  onToggleAdvancedFilters,
  onClearFilters
}: LogFilterSectionProps) => {
  return (
    <div className="p-4 border-b border-cyrus-dark-lightest">
      <div className="relative">
        <input
          type="text"
          placeholder="Search logs..."
          className="w-full bg-cyrus-dark-lighter border border-cyrus-dark-lightest rounded pl-10 pr-3 py-2 text-white"
          value={filter}
          onChange={(e) => onFilterChange(e.target.value)}
        />
        <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
      </div>
      
      {showAdvancedFilters && (
        <div className="mt-3 bg-cyrus-dark p-3 rounded-md">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-sm font-medium text-cyrus-gold">Advanced Filters</h3>
            <button 
              className="text-xs text-gray-400 hover:text-white"
              onClick={onClearFilters}
            >
              Clear Filters
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Item Name</label>
              <input
                type="text"
                className="w-full bg-cyrus-dark-lighter border border-cyrus-dark-lightest rounded px-3 py-1 text-white text-sm"
                value={filterOptions.itemName}
                onChange={(e) => onFilterOptionsChange('itemName', e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-xs text-gray-400 mb-1">Field</label>
              <input
                type="text"
                className="w-full bg-cyrus-dark-lighter border border-cyrus-dark-lightest rounded px-3 py-1 text-white text-sm"
                value={filterOptions.field}
                onChange={(e) => onFilterOptionsChange('field', e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-xs text-gray-400 mb-1">Value Changed</label>
              <input
                type="text"
                className="w-full bg-cyrus-dark-lighter border border-cyrus-dark-lightest rounded px-3 py-1 text-white text-sm"
                value={filterOptions.valueChanged}
                onChange={(e) => onFilterOptionsChange('valueChanged', e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-xs text-gray-400 mb-1">From Date</label>
              <input
                type="date"
                className="w-full bg-cyrus-dark-lighter border border-cyrus-dark-lightest rounded px-3 py-1 text-white text-sm"
                value={filterOptions.dateFrom}
                onChange={(e) => onFilterOptionsChange('dateFrom', e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-xs text-gray-400 mb-1">To Date</label>
              <input
                type="date"
                className="w-full bg-cyrus-dark-lighter border border-cyrus-dark-lightest rounded px-3 py-1 text-white text-sm"
                value={filterOptions.dateTo}
                onChange={(e) => onFilterOptionsChange('dateTo', e.target.value)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LogFilterSection;
