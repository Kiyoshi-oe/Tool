import { useState, useEffect } from "react";
import { ResourceItem, FileData, LogEntry } from "../types/fileTypes";
import { parseTextFile, getPropItemMappings } from "../utils/file";
import { parsePropItemFile } from "../utils/file/propItemUtils";
import { toast } from "sonner";

interface UndoRedoState {
  items: ResourceItem[];
  selectedItem: ResourceItem | null;
}

export const useResourceState = (settings: any, setLogEntries: React.Dispatch<React.SetStateAction<LogEntry[]>>) => {
  const [fileData, setFileData] = useState<FileData | null>(null);
  const [selectedItem, setSelectedItem] = useState<ResourceItem | null>(null);
  const [undoStack, setUndoStack] = useState<UndoRedoState[]>([]);
  const [redoStack, setRedoStack] = useState<UndoRedoState[]>([]);
  const [openTabs, setOpenTabs] = useState<{id: string, item: ResourceItem}[]>([]);
  const [editMode, setEditMode] = useState(false);
  
  const saveUndoState = () => {
    if (!fileData) return;
    
    setUndoStack(prev => [
      ...prev, 
      { 
        items: JSON.parse(JSON.stringify(fileData.items)),
        selectedItem: selectedItem ? JSON.parse(JSON.stringify(selectedItem)) : null
      }
    ]);
    setRedoStack([]);
  };
  
  const handleUndo = () => {
    if (undoStack.length === 0 || !fileData) return;
    
    const currentState = {
      items: JSON.parse(JSON.stringify(fileData.items)),
      selectedItem: selectedItem ? JSON.parse(JSON.stringify(selectedItem)) : null
    };
    
    const prevState = undoStack[undoStack.length - 1];
    
    setRedoStack(prev => [...prev, currentState]);
    setUndoStack(prev => prev.slice(0, -1));
    
    if (fileData) {
      setFileData({
        ...fileData,
        items: prevState.items
      });
    }
    
    setSelectedItem(prevState.selectedItem);
    toast.info("Undo successful");
  };
  
  const handleRedo = () => {
    if (redoStack.length === 0 || !fileData) return;
    
    const currentState = {
      items: JSON.parse(JSON.stringify(fileData.items)),
      selectedItem: selectedItem ? JSON.parse(JSON.stringify(selectedItem)) : null
    };
    
    const nextState = redoStack[redoStack.length - 1];
    
    setUndoStack(prev => [...prev, currentState]);
    setRedoStack(prev => prev.slice(0, -1));
    
    if (fileData) {
      setFileData({
        ...fileData,
        items: nextState.items
      });
    }
    
    setSelectedItem(nextState.selectedItem);
    toast.info("Redo successful");
  };
  
  const handleLoadFile = (content: string, propItemContent?: string) => {
    try {
      console.log("handleLoadFile called with content length:", content.length);
      console.log("propItemContent provided:", !!propItemContent);
      
      if (propItemContent) {
        console.log("propItemContent provided, parsing...");
        parsePropItemFile(propItemContent);
        console.log("PropItem mappings loaded");
      }
      
      const data = parseTextFile(content);
      console.log("File data loaded:", data.items.length, "items");
      
      // Force a clean state update
      setFileData(null);
      setSelectedItem(null);
      
      // Then set the new data
      setTimeout(() => {
        if (data.items.length > 0) {
          const propMappings = getPropItemMappings();
          console.log("Available mappings for items:", Object.keys(propMappings).length);
          
          // Apply the name and description mappings to all items
          data.items = data.items.map(item => {
            const idPropItem = item.data.szName as string;
            if (idPropItem && propMappings[idPropItem]) {
              console.log(`Applying mapping for item ${item.id}: ${idPropItem} -> "${propMappings[idPropItem].displayName}"`);
              return {
                ...item,
                displayName: propMappings[idPropItem].displayName || idPropItem,
                description: propMappings[idPropItem].description || ""
              };
            }
            return item;
          });
        }
        
        setFileData(data);
        
        if (data.items.length > 0) {
          console.log("First few items after name mapping:", data.items.slice(0, 3).map(
            item => `${item.id}: ${item.displayName || item.name} - ${item.description?.substring(0, 30) || 'No description'}`
          ));
        }
        
        if (settings.enableLogging) {
          const newLogEntry: LogEntry = {
            timestamp: Date.now(),
            itemId: "file-load",
            itemName: "File Load",
            field: "file",
            oldValue: "",
            newValue: `Loaded at ${new Date().toLocaleTimeString()}${propItemContent ? ' with propItem mappings' : ''}`
          };
          setLogEntries(prev => [newLogEntry, ...prev]);
        }
        
        toast.success(`File loaded successfully with ${data.items.length} items${propItemContent ? ' and item names from propItem.txt.txt' : ''}`);
      }, 0);
    } catch (error) {
      toast.error("Error parsing file");
      console.error("Error parsing file:", error);
    }
  };
  
  const handleSelectItem = (item: ResourceItem, showSettings: boolean, showToDoPanel: boolean) => {
    if (showSettings || showToDoPanel) return;
    
    saveUndoState();
    
    setSelectedItem(item);
    
    if (!openTabs.some(tab => tab.id === item.id)) {
      setOpenTabs(prev => [...prev, { id: item.id, item }]);
    }
  };
  
  const handleUpdateItem = (updatedItem: ResourceItem, field?: string, oldValue?: any) => {
    if (!fileData || !editMode) return;
    
    const updatedItems = fileData.items.map(item => 
      item.id === updatedItem.id ? updatedItem : item
    );
    
    setFileData({
      ...fileData,
      items: updatedItems
    });
    
    setOpenTabs(prev => prev.map(tab => 
      tab.id === updatedItem.id ? { ...tab, item: updatedItem } : tab
    ));
    
    if (settings.enableLogging && field && oldValue !== undefined) {
      const newLogEntry: LogEntry = {
        timestamp: Date.now(),
        itemId: updatedItem.id,
        itemName: updatedItem.name,
        field,
        oldValue,
        newValue: updatedItem.data[field] || ''
      };
      
      setLogEntries(prev => [newLogEntry, ...prev]);
    }
    
    setSelectedItem(updatedItem);
  };
  
  const handleCloseTab = (tabId: string) => {
    setOpenTabs(prev => prev.filter(tab => tab.id !== tabId));
    
    if (selectedItem && selectedItem.id === tabId) {
      const remainingTabs = openTabs.filter(tab => tab.id !== tabId);
      if (remainingTabs.length > 0) {
        setSelectedItem(remainingTabs[remainingTabs.length - 1].item);
      } else {
        setSelectedItem(null);
      }
    }
  };
  
  const handleSelectTab = (tabId: string) => {
    const tab = openTabs.find(t => t.id === tabId);
    if (tab) {
      setSelectedItem(tab.item);
    }
  };
  
  const handleToggleEditMode = () => {
    setEditMode(!editMode);
    toast.info(editMode ? "Switched to View mode" : "Switched to Edit mode");
  };
  
  return {
    fileData,
    setFileData,
    selectedItem,
    setSelectedItem,
    undoStack,
    redoStack,
    openTabs,
    editMode,
    saveUndoState,
    handleUndo,
    handleRedo,
    handleLoadFile,
    handleSelectItem,
    handleUpdateItem,
    handleCloseTab,
    handleSelectTab,
    handleToggleEditMode
  };
};
