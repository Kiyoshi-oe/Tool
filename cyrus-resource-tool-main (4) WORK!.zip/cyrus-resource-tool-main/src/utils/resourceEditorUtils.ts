
// Helper utilities for resource editor components

// Function to determine if a file extension is supported for preview
export const isSupportedImageFormat = (filename: string): boolean => {
  if (!filename) return false;
  const ext = filename.toLowerCase().split('.').pop();
  return ['png', 'jpg', 'jpeg', 'dds', 'gif', 'bmp', 'webp'].includes(ext || '');
};

// Function to get the full path for the icon based on filename
export const getIconPath = (iconName: string): string => {
  if (!iconName) return '';
  
  // Remove any quotes that might be in the path
  const cleanIconName = iconName.replace(/["""]/g, '');
  
  // Check if the path already has a leading slash or contains http/https
  if (cleanIconName.startsWith('/') || cleanIconName.startsWith('http')) {
    return cleanIconName;
  }
  
  // Use absolute path starting with / to ensure it looks in the public folder
  const iconPath = `/resource/Item/${cleanIconName}`;
  console.log(`Resolving icon path for ${cleanIconName} to ${iconPath}`);
  return iconPath;
};

// Option arrays for dropdown selects
export const effectTypes = [
  'DST_ADJDEF', 'DST_ATKPOWER', 'DST_STR', 'DST_STA', 'DST_HP_MAX_RATE',
  'DST_ADJDEF_RATE', 'DST_BLOCK_MELEE', 'DST_BLOCK_RANGE', 'DST_DEX',
  'DST_INT', 'DST_MP_MAX', 'DST_HP_MAX', 'DST_SPELL_RATE',
  'DST_CRITICAL_RATE', 'DST_FP_RATE', 'DST_ATTACKSPEED',
  'DST_CHR_STEALHP', 'DST_REFLECT_DAMAGE', 'DST_RESIST_LIGHTNING',
  'DST_RESIST_FIRE', 'DST_RESIST_EARTH', 'DST_RESIST_WATER', 'DST_RESIST_WIND',
  'DST_MP_DEC_RATE', 'DST_HP_RECOVERY', 'DST_MP_RECOVERY', 'DST_KILL_HP',
  'DST_KILL_MP', 'DST_EXPERIENCE', 'DST_GOLD', 'DST_HITRATE', 'DST_PARRY',
  'DST_ALL_STAT', 'DST_DMG_REFLECTION'
];

export const itemKind1Options = [
  'IK1_WEAPON', 'IK1_ARMOR', 'IK1_GENERAL', 'IK1_RIDE', 'IK1_SYSTEM',
  'IK1_CHARGED', 'IK1_TREASURE', 'IK1_CONSUMABLE', 'IK1_MATERIAL'
];

export const itemKind2Options = [
  'IK2_WEAPON_DIRECT', 'IK2_WEAPON_MAGIC', 'IK2_ARMOR', 'IK2_ARMORETC',
  'IK2_CLOTH', 'IK2_JEWELRY', 'IK2_FOOD', 'IK2_POTION', 'IK2_BUFF',
  'IK2_QUEST', 'IK2_MATERIAL_GENERAL'
];

export const itemKind3Options = [
  'IK3_AXE', 'IK3_SWD', 'IK3_STICK', 'IK3_STAFF', 'IK3_HELMET',
  'IK3_SUIT', 'IK3_GAUNTLET', 'IK3_BOOTS', 'IK3_SHIELD', 'IK3_CLOAK',
  'IK3_MASK', 'IK3_RING', 'IK3_EARRING', 'IK3_NECKLACE', 'IK3_BRACELET'
];

export const jobOptions = [
  'JOB_VAGRANT', 'JOB_MERCENARY', 'JOB_ACROBAT', 'JOB_ASSIST',
  'JOB_MAGICIAN', 'JOB_KNIGHT', 'JOB_BLADE', 'JOB_JESTER',
  'JOB_RANGER', 'JOB_RINGMASTER', 'JOB_BILLPOSTER', 'JOB_PSYCHIKEEPER',
  'JOB_ELEMENTOR', 'JOB_KNIGHT_MASTER', 'JOB_BLADE_MASTER',
  'JOB_JESTER_MASTER', 'JOB_RANGER_MASTER', 'JOB_RINGMASTER_MASTER',
  'JOB_BILLPOSTER_MASTER', 'JOB_PSYCHIKEEPER_MASTER',
  'JOB_ELEMENTOR_MASTER', 'JOB_KNIGHT_HERO', 'JOB_BLADE_HERO',
  'JOB_JESTER_HERO', 'JOB_RANGER_HERO', 'JOB_RINGMASTER_HERO',
  'JOB_BILLPOSTER_HERO', 'JOB_PSYCHIKEEPER_HERO',
  'JOB_ELEMENTOR_HERO', 'JOB_ALL'
];

export const attackStyleOptions = [
  'AS_HORIZONTAL', 'AS_VERTICAL', 'AS_DIAGONAL', 'AS_THRUST'
];

export const weaponTypeOptions = [
  'WT_MELEE_SWD', 'WT_MELEE_AXE', 'WT_MELEE_STAFF', 'WT_RANGE_BOW', 
  'WT_MAGIC_WAND', 'WT_RANGE_GUN'
];

export const itemGradeOptions = [
  'ITEM_GRADE_NORMAL', 'ITEM_GRADE_RARE', 'ITEM_GRADE_UNIQUE', 'ITEM_GRADE_ULTIMATE'
];
